# CLI Favorite [![Build Status](https://travis-ci.org/dutchakdev/clif.png)](https://travis-ci.org/dutchakdev/clif)

## Introduction

Favorites for CLI. Save your commands in category interactive.

## Requirements

## Installation

## Configuration

## Documentation

## Troubleshooting/Issues

## FAQ

## Maintainers/Sponsors

## Development

## License

[GPLv3](http://www.gnu.org/licenses/gpl-3.0.txt)